"""
##### 0) Header #####
# Text Adventure Game
A chance to make your own Text Adventure Game.
This is an INDIVIDUAL project. Do not consult with others or share code.
Refer to the instructions on Canvas for more information.

# When You Are Done
When you pass all tests, remember to clean and document your code.
Be sure to unit test and document your functions.
"""

##### 1) Author Info #####

# Change these three fields
__author__ = "sunxinyi@udel.edu"
__title__ = "Harry Potter World "
__description__ = "Hogwarts is a very mysterious school, now you need to uncover the mystery in this school."

# Leave these two fields unchanged
__version__ = 1
__date__ = "Spring 2019"


##### 2) Record Definitions #####
# Add a new record and modify the existing ones to fit your game.

'''
Records:
    World:
        status (str): Whether or not the game is "playing", "won",
                      "Quit", or "lose". Initially "playing".
        map (dict[str: Location]): The lookup dictionary matching
                                   location names to their
                                   information.
        player (Player): The player character's information.

      
    Player:
        location (str): The name of the player's current location.
        inventory (list[str]): The player's collection of items.
                               Initially empty.

    Location:
        about (str): A sentence that describes what this location 
                     looks like.
        neighbors (list[str]): A list of the names of other places 
                               that you can reach from this 
                               location.
        stuff (list[str]): A collection of things available at 
                           this location.
                           
        incantation(str): The key factor to decided whether you won. you have to choose it. 
        wand(bool):Whether you have wand. "Wand" is look like a key.
        
'''

##### 3) Core Game Functions #####
# Implement the following to create your game.
inventory = []
def render_introduction():
    '''
    Create the message to be displayed at the start of your game.
    
    Returns:
        str: The introductory text of your game to be displayed.
    '''
    return ("== You Are a Brave Guy ==\n"+
            " = By Xinyi =\n"+
            "\n"+
            "Hi!! Welcome to the Hogwarts school and hope you enjoy this travel ,\n"+
            "you will have some step to finsih.")



    
      

def create_world():
    '''
    Creates a new version of the world in its initial state.
    
    Returns:
        World: The initial state of the world
    '''
    

    return {
        'map': create_map(),
        'player': create_player(),
        'status': "playing"
    }
    
def create_player():
    '''
    Creates a new version of the world in its initial state.
    
    Returns:
        World: The initial state of the world
    '''
    return {
        'location': 'Hogwarts School',
        'inventory': [],
       
    }
    
def create_map():
    '''
    Creates a new version of the map in its initial state.
    
    Returns:
           Map: The initial state of the map
    '''
    return {
        'Hogwarts School': {
            'neighbors': ['Dumbledore Office', 'Gryffindor Department','Library'],
            'about': "our school have a chamber we need to find the wand.after that you need to open the chamber with correct incantation.Than you could won!",
            'stuff': [],
        },
        
        'Library': {
            'neighbors': ['Student Lounge'],
            'about': "The Library are closed",
            'stuff': [],
        },
        
        'Dumbledore Office': {
            'neighbors': ['Student Lounge'],
            'about': "you have got into the office but there are nothing.",
            'stuff': []
        },
        'Gryffindor Department': {
            'neighbors': ['Student Lounge'],
            'about': "You are very surprised because this is the first time you have been here. while you are walking, you saw the studnet lounge",
            'stuff': ["key"]
        },
        'Student Lounge': {
            'neighbors': ["choose petrificus totalus","choose Avada Kedavra"],
            'about': "using wand to choose correct one to open chamber",
            'stuff': [ ]
        },
    }
    
def render(world):
    '''
    Consumes a world and produces a string that will describe the current state
    of the world. Does not print.
    
    Args:
        world (World): The current world to describe.
    
    Returns:
        str: A textual description of the world.
        
    '''
    return (render_location(world) +
            render_player(world) +
            render_visible_stuff(world))

def render_location(world):
    '''
    Create the message to be displayed at the end of your game.
    
    Args:
        world (World): The final world state to use in describing the ending.
    
    Returns:
        str: The ending text of your game to be displayed.
    '''
    location = world['player']['location']
    here = world['map'][location]
    about = here['about']
    return ("You are in "+location+" "+
            about+" ")

def render_player(world):
    '''
    Consumes a world and produces a string that will describe the current location
    of the world. Does not print.
    
    Args:
        world (World): The current world to describe.
    
    Returns:
        str: A textual description of the location.
    '''
    location= world['player']['location']
    here = world['map'][location]
    about = here['about']
    return ("You see"+" "+about+" ")
    

def render_visible_stuff(world):
    '''
    Consumes a world and produces a string that will describe inventory the 
    player have. Does not print.
    
    Args:
        world (World): The current world to describe.
    
    Returns:
        str: A textual description inventory.
    '''
    location = world['player']['location']
    here = world['map'][location]
    stuff = here['stuff']
   
    visible_stuff = []
    for thing in stuff:
        visible_stuff.append(thing)
    return "what happend now: " + ', '.join(visible_stuff)
    


def get_options(world):
    '''
    Consumes a world and produces a list of strings representing the options
    that are available to be chosen given this state.
    
    Args:
        world (World): The current world to get options for.
    
    Returns:
        list[str]: The list of commands that the user can choose from.
    '''
    commands = ["Quit"]
    
    location=world['player']['location']
    if location == 'Hogwarts School':
        print("Guess where is the wand?")
        commands.append("go to Gryffindor Department")
        commands.append("go to Library")
        commands.append("go to Dumbledore Office")
        
        
        
    if location == 'Gryffindor Department':
        print("chamber is in the student lounge,go ahead!")
        commands.append("go to Student Lounge")
        
        
    
    if location=='Dumbledore Office':
        print("you greet with dembledore and he tells you chamber is in the student lounge")
        commands.append("go to Student Lounge")
        commands.append("choose Avada Kedavra")
        
        
    if location=="Library":
        print("Omggg! Library is closed,so I suggest you to choose other ones")
        commands.append("go to Student Lounge")
        commands.append("go to Dumbledore Office")
        
    
    if location=="Student Lounge":
        print("yes! you are find the chamber,so use your wand to open chamber.But just one of it works.")
        commands.append("choose petrificus totalus")
        commands.append("choose Avada Kedavra")
        
        
        
        
    return commands
def update(world,command):
    '''
    Consumes a world and a command and updates the world according to the
    command, also producing a message about the update that occurred. This
    function should modify the world given, not produce a new one.
    
    Args:
        world (World): The current world to modify.
    
    Returns:
        str: A message describing the change that occurred in the world.
    '''
    if command == "go to Dumbledore Office":
        world['player']['location'] ='Dumbledore Office'
        
    if command=="go to Library":
        world['player']['location'] ='Library'
        
    if command=="go to Gryffindor Department":
        world['player']['location'] ='Gryffindor Department'
        inventory.append("key")
  
    if command=="go to Student Lounge":
        world['player']['location'] ='Student Lounge'
    if command=="Quit":
        world["status"]="Quit"
        
    if command=="choose petrificus totalus" and "key" in inventory:
        world['status'] = 'won'
    elif command=="choose petrificus totalus" and "key" not in inventory:
        world['status'] = 'lost'
        
    if command=="choose Avada Kedavra":
        world['status'] = 'lost'
    return "you "+" "+command


def goto(world, command):
    '''
    Create the message to be displayed at the end of your game.
    
    Args:
        world (World): The final world state to use in describing the ending.
    
    Returns:
        str: The ending text of your game to be displayed.
    '''
    new_location = command[len('go to '):]
    world['player']['location'] = new_location
    return "You went to "+new_location

       


       
def render_ending(world):
    '''
    Create the message to be displayed at the end of your game.
    
    Args:
        world (World): The final world state to use in describing the ending.
    
    Returns:
        str: The ending text of your game to be displayed.
    '''
       
    if world['status'] == 'won':
        if "key" in inventory:
            return "you won!"
        else:
            return "sorry,nothing here"
            
    elif world['status']=='lose':
        return "you lose"
    elif world["status"]=="Quit":
        return "you Quit"
    elif  world["status"]=="lost":
        return"Sorry!You didn't find your wand at the beginning, so you lost."
    

    
       
       
    

def choose(options):
    '''
    Consumes a list of commands, prints them for the user, takes in user input
    for the command that the user wants (prompting repeatedly until a valid
    command is chosen), and then returns the command that was chosen.
    
    Note:
        Use your answer to Programming Problem #42.3
    
    Args:
        options (list[str]): The potential commands to select from.
    
    Returns:
        str: The command that was selected by the user.
    '''
    print("Your options are: ")
    for cmd in options:
        print(cmd)
    user_input = " "
    while user_input not in options:
        user_input = input("What would you like to do?")
    return user_input



###### 4) Win/lose Paths #####
# The autograder will use these to try out your game
# WIN_PATH (list[str]): A list of commands that win the game when entered
# lose_PATH (list[str]): A list of commands that lose the game when entered.

WIN_PATH = ["go to Gryffindor Department","go to Student Lounge","choose petrificus totalus"]
LOSE_PATH = ["go to Dumbledore Office","choose Avada Kedavra"]
    
###### 5) Unit Tests #####
# Write unit tests here

from cisc108 import assert_equal
assert_equal("Harry Potter World" in render_introduction(),True)
assert_equal(render_introduction().count("\n"),4)
assert_equal("you will" in render_introduction().lower(),True)
player = create_player()
assert_equal(isinstance(player, dict), True)
assert_equal(len(player.keys()), 2)
assert_equal("location" in player, True)
assert_equal(player['location'], 'Hogwarts School')
assert_equal("inventory" in player, True)
assert_equal(player['inventory'], [])
world = create_world()
assert_equal(isinstance(world, dict), True)
assert_equal("status" in world,True)
assert_equal("map" in world,True)
assert_equal("player" in world,True)
assert_equal(world['status'], 'playing')
assert_equal(world['map'], create_map())
assert_equal(isinstance(world['map'], dict), True)
assert_equal("key" in render(world), True)
commands=get_options(world)
assert_equal("go to Gryffindor Department" in commands,True)
assert_equal("go to Library" in commands,True)

world['player']['location']='Hogwarts School'
assert_equal(get_options(world),"Guess where is the wand?")
commands=get_options(world)
assert_equal("go to Dumbledore Office" in commands,True)
assert_equal("go to Gryffindor Department" in commands,True)
assert_equal("go to Library" in commands,True)

world['player']['location']='Gryffindor Department'
assert_equal(get_options(world),"go ahead!")
commands=get_options(world)
assert_equal("go to Student Lounge" in commands,True)

world['player']['location']='Dumbledore Office'
assert_equal(get_options(world),"You greet Professor Dumbledore and he tells you chamber is in the student lounge")
commands=get_options(world)
assert_equal("go to Student Lounge"in commands,True)

world['player']['location']="Library"
assert_equal(get_options(world),"Omgggg!Library is closed,so I suggest you to choose other ones")
commands=get_options(world)
assert_equal("go to Student Lounge"in commands,True)
assert_equal("go to Dumbledore Office"in commands,True)

world['player']['location']="Student Lounge"
assert_equal(get_options(world),"Yes! you have found the chamber,so make a decision which incantations could open the chamber.")
commands=get_options(world)
assert_equal("choose petrificus totalus"in commands,True)
assert_equal("choose Avada Kedavra"in commands,True)

update(world,'Quit')
assert_equal(world['status'],'quit')

update(world,"choose Avada Kedavra")
assert_equal(world['status'],'lost')

update(world,"choose petrificus totalus")
assert_equal(world['status'],'lost')

update(world,"choose petrificus totalus")
assert_equal(world['status'],'won')

update(world,"go to Dumbledore Office")
assert_equal(world['player']['location'],'Dumbledore Office')

update(world,"go to Library")
assert_equal(world['player']['location'],"Library")

update(world,"go to Gryffindor Department")
assert_equal(world['player']['location'],"Gryffindor Department")

update(world,"go to Student Lounge")
assert_equal(world['player']['location'],"Student Lounge")

world['status'] = 'won'
assert_equal(render_ending(world),"you won!")
world['status'] ='quit'
assert_equal(render_ending(world),"You quit.")
world['status'] ='lost'
assert_equal(render_ending(world),"Sorry!You didn't find your wand at the beginning, so you lost.")
world['status'] = 'lose'
assert_equal(render_ending(world),"you lose")


world = create_world()
assert_equal(render(world), 'You are in Hogwarts School our school have a chamber we need to find the wand.after that you need to open the chamber with correct incantation.Than you could won! You see our school have a chamber we need to find the wand.after that you need to open the chamber with correct incantation.Than you could won! what happend now:')






















###### 6) Main Function #####
# Do not modify this area

def main():
    '''
    Run your game using the Text Adventure console engine.
    Consumes and produces nothing, but prints and indirectly takes user input.
    '''
    print(render_introduction())
    world = create_world()
    while world['status'] == 'playing':
        print(render(world))
        options = get_options(world)
        command = choose(options)
        print(update(world, command))
    print(render_ending(world))

if __name__ == '__main__':
    main()

        
    




